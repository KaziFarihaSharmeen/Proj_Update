# UBPLC Forms Project
Make sure to include the `lib/mssql-jdbc-13.4.0.jre11.jar` file through the project structure option.

*Run the sql commands from lib format*



#### TODO
* In corporate Branches
* Include Validations
* Include User Auth