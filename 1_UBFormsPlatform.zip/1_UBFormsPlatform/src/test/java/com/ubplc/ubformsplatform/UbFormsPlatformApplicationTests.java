package com.ubplc.ubformsplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UbFormsPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
