package com.ubplc.ubformsplatform.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@Component
public class JDBCConfig {

    private static DataSource dataSource;

    @Autowired
    public JDBCConfig(DataSource dataSource) {
        JDBCConfig.dataSource = dataSource;
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}