package com.ubplc.ubformsplatform.Branches;

import com.ubplc.ubformsplatform.DTO.Branches.BranchDTO;
import com.ubplc.ubformsplatform.Branches.BranchService.BranchService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BranchController {

    private final BranchService branchService;

    public BranchController(BranchService branchService) {
        this.branchService = branchService;
    }

    // Display all branches
    @GetMapping("/branches")
    public String getBranches(Model model) {

        List<BranchDTO> branches = branchService.findAll();

        model.addAttribute("branches", branches);

        return "branches";
    }

    // Display one branch by branch code
    @GetMapping("/branch/{branchCode}")
    public String getBranchByBranchCode(@PathVariable String branchCode,
                                        Model model) {

        BranchDTO branch = branchService.findByBranchCode(branchCode);

        model.addAttribute("branch", branch);

        return "branch";
    }

    // Open Create Branch Page
    @GetMapping("/branch")
    public String createBranchView(Model model) {

        model.addAttribute("branchDto", new BranchDTO());

        return "create-branch";
    }

    // Save Branch
    @PostMapping("/branch/create")
    public String createBranchForm(
            @Valid @ModelAttribute("branchDto") BranchDTO branchDto,
            BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            return "create-branch";
        }

        BranchDTO savedBranch = branchService.save(branchDto);

        model.addAttribute("branch", savedBranch);

        return "branch";
    }
    // Open Edit Page
    @GetMapping("/branch/edit/{branchCode}")
    public String editBranch(@PathVariable String branchCode, Model model) {

        BranchDTO branch = branchService.findByBranchCode(branchCode);

        model.addAttribute("branchDto", branch);

        return "edit-branch";
    }


    // Update Branch
    @PostMapping("/branch/update")
    public String updateBranch(
            @Valid @ModelAttribute("branchDto") BranchDTO branchDto,
            BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            return "edit-branch";
        }

        BranchDTO updatedBranch = branchService.update(branchDto);

        model.addAttribute("branch", updatedBranch);

        return "branch";
    }

    @GetMapping("/branch/delete/{branchCode}")
    public String deleteBranch(@PathVariable String branchCode) {

        branchService.delete(branchCode);

        return "redirect:/branches";
    }

    @GetMapping("/branch/search")
    public String searchBranch(@RequestParam String branchCode,
                               Model model) {

        BranchDTO branch = branchService.search(branchCode);

        model.addAttribute("branch", branch);

        return "branch";
    }
}