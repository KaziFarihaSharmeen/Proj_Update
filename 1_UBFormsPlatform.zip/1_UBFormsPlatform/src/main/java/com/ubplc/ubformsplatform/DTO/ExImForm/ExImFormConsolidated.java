package com.ubplc.ubformsplatform.DTO.ExImForm;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class ExImFormConsolidated {
    private int formId;
    private String branchCode;
    private ExImFormMIS exImFormMIS;
    private ExImFormBranch exImFormBranch;
}
