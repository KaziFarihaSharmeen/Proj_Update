package com.ubplc.ubformsplatform.Assignments.AssignmentService;

import com.ubplc.ubformsplatform.Assignments.FormAssignment;

import java.util.List;

public interface AssignmentService {

    FormAssignment save(FormAssignment assignment);

    List<FormAssignment> findAll();

    List<FormAssignment> findByBranchCode(String branchCode);

}