package com.ubplc.ubformsplatform.Assignments;

import com.ubplc.ubformsplatform.Assignments.AssignmentService.AssignmentService;
import com.ubplc.ubformsplatform.Branches.BranchService.BranchService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/assignments")
public class AssignmentController {

    private final AssignmentService assignmentService;
    private final BranchService branchService;

    public AssignmentController(AssignmentService assignmentService,
                                BranchService branchService) {
        this.assignmentService = assignmentService;
        this.branchService = branchService;
    }

    // Show Assignment Page
    @GetMapping("/new")
    public String assignmentPage(Model model) {

        model.addAttribute("assignment", new FormAssignment());

        model.addAttribute("branches", branchService.findAll());

        return "assign-form";
    }

    // Save Assignment
    @PostMapping("/save")
    public String saveAssignment(
            @Valid @ModelAttribute("assignment") FormAssignment assignment,
            Model model) {

        FormAssignment savedAssignment = assignmentService.save(assignment);

        model.addAttribute("assignment", savedAssignment);

        return "assignment-success";
    }

    // View All Assignments
    @GetMapping
    public String viewAssignments(Model model) {

        model.addAttribute("assignments", assignmentService.findAll());

        return "assigned-forms";
    }

}