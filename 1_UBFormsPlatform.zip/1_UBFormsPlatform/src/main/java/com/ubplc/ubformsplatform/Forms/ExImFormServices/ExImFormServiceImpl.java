package com.ubplc.ubformsplatform.Forms.ExImFormServices;

import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormBranch;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormConsolidated;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormMIS;
import com.ubplc.ubformsplatform.Forms.ExImFormRepositories.ExImFormRepositoryImpl;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ExImFormServiceImpl implements ExImFormService {
    private final ExImFormRepositoryImpl exImFormRepositoryImpl;

    ExImFormServiceImpl(ExImFormRepositoryImpl exImFormRepositoryImpl) {
        this.exImFormRepositoryImpl = exImFormRepositoryImpl;
    }

    @Override
    public int save(ExImFormMIS exImFormMIS) {
        return this.exImFormRepositoryImpl.save(exImFormMIS);
    }

    @Override
    public ExImFormConsolidated update(int formId,ExImFormBranch exImFormBranch) {
        return this.exImFormRepositoryImpl.update(formId, exImFormBranch);
    }

    @Override
    public List<ExImFormConsolidated> getAllForms() {
        return this.exImFormRepositoryImpl.getAllForms();
    }

    @Override
    public String delete(String branchCode) {
        return this.exImFormRepositoryImpl.delete(branchCode);
    }
    @Override
    public ExImFormConsolidated getFormById(int formId) {
        return this.exImFormRepositoryImpl.getFormById(formId);
    }
}
