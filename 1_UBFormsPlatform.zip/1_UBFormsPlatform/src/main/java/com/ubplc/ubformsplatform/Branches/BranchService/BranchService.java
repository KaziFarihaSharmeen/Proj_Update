package com.ubplc.ubformsplatform.Branches.BranchService;

import java.util.List;

import com.ubplc.ubformsplatform.DTO.Branches.BranchDTO;

public interface BranchService {

    BranchDTO save(BranchDTO branchRequest);

    BranchDTO findByBranchCode(String branchCode);

    List<BranchDTO> findAll();

    BranchDTO update(BranchDTO branchRequest);

    void delete(String branchCode);

    BranchDTO search(String branchCode);

}