package com.ubplc.ubformsplatform.DTO.ExImForm;

import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class ExImFormBranch {
    private String branchCode;
    private int importLCActualCount;
    private double importLCActualAmount;
    private int exportLCActualCount;
    private double exportLCActualAmount;
    private LocalDate updateDate;
}
