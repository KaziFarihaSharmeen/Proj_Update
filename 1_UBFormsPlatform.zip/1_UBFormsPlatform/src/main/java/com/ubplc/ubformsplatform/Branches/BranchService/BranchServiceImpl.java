package com.ubplc.ubformsplatform.Branches.BranchService;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ubplc.ubformsplatform.DTO.Branches.BranchDTO;
import com.ubplc.ubformsplatform.Branches.BranchRepository.BranchRepository;

@Service
public class BranchServiceImpl implements BranchService {

    private final BranchRepository branchRepository;

    public BranchServiceImpl(BranchRepository branchRepository) {
        this.branchRepository = branchRepository;
    }

    @Override
    public BranchDTO save(BranchDTO branchRequest) {
        return branchRepository.save(branchRequest);
    }

    @Override
    public BranchDTO findByBranchCode(String branchCode) {
        return branchRepository.findByBranchCode(branchCode);
    }

    @Override
    public List<BranchDTO> findAll() {
        return branchRepository.findAll();
    }

    @Override
    public BranchDTO update(BranchDTO branchRequest) {
        return branchRepository.update(branchRequest);
    }

    @Override
    public void delete(String branchCode) {
        branchRepository.delete(branchCode);
    }
    @Override
    public BranchDTO search(String branchCode) {
        return branchRepository.search(branchCode);
    }
}