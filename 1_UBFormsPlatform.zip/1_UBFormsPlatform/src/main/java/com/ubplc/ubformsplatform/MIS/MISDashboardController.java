package com.ubplc.ubformsplatform.MIS;

import com.ubplc.ubformsplatform.Branches.BranchService.BranchService;
import com.ubplc.ubformsplatform.Forms.ExImFormServices.ExImFormServiceImpl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class MISDashboardController {


    private final ExImFormServiceImpl exImFormService;
    private final BranchService branchService;


    public MISDashboardController(
            ExImFormServiceImpl exImFormService,
            BranchService branchService
    ) {

        this.exImFormService = exImFormService;
        this.branchService = branchService;

    }



    @GetMapping("/mis/dashboard")
    public String dashboard(Model model) {


        // Total created MIS forms
        model.addAttribute(
                "totalForms",
                exImFormService.getAllForms().size()
        );


        // Total branches
        model.addAttribute(
                "totalBranches",
                branchService.findAll().size()
        );


        // Temporary values
        // will connect with Assignment table later
        model.addAttribute(
                "assignedForms",
                0
        );


        model.addAttribute(
                "pendingForms",
                0
        );


        return "mis-dashboard";

    }

}