package com.ubplc.ubformsplatform.Reports;

import java.util.List;

import com.ubplc.ubformsplatform.DTO.Report.Report;



public interface ReportService {
    Report createReportByBranchCode(String reportName, String branchCode);
    List<Report> showFullReport();
}
