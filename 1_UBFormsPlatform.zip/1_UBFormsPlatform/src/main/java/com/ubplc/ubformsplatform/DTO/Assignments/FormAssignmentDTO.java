package com.ubplc.ubformsplatform.DTO.Assignments;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FormAssignmentDTO {

    private Integer assignmentId;

    private String formName;

    private String branchCode;

    private String assignedBy;

    private LocalDateTime assignedAt;

    private LocalDateTime deadlineAt;

    private String status;

    private LocalDateTime submittedAt;

    private String remarks;

}