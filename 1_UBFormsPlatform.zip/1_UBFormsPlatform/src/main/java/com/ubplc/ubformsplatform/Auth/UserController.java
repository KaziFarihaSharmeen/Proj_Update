package com.ubplc.ubformsplatform.Auth;

import jakarta.servlet.http.HttpServletResponse;
import com.ubplc.ubformsplatform.Auth.UserService.UserService;
import com.ubplc.ubformsplatform.DTO.Auth.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String loginPage(Model model) {

        model.addAttribute("user", new UserDTO());

        return "login";
    }
    @PostMapping("/login")
    public String login(
            @ModelAttribute("user") UserDTO user,
            Model model
    ) {

        UserDTO loginUser = userService.login(
                user.getUsername(),
                user.getPassword()
        );

        if (loginUser == null) {

            model.addAttribute("error",
                    "Invalid Username or Password");

            return "login";
        }

        // Cookie will be added later

        return "redirect:/dashboard";
    }


    @GetMapping("/register")
    public String registerPage(Model model) {

        model.addAttribute("user", new UserDTO());

        return "register";
    }
    @PostMapping("/register")
    public String register(
            @ModelAttribute("user") UserDTO user,
            Model model
    ) {

        boolean success = userService.register(user);

        if (!success) {

            model.addAttribute("error",
                    "Username already exists.");

            return "register";
        }

        return "redirect:/login";
    }

}