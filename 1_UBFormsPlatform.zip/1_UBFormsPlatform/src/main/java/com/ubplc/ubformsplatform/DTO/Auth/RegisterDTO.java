package com.ubplc.ubformsplatform.DTO.Auth;

public class RegisterDTO {
}
