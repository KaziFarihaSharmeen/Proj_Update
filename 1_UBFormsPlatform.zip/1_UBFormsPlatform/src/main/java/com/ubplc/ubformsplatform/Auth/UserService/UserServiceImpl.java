package com.ubplc.ubformsplatform.Auth.UserService;

import com.ubplc.ubformsplatform.Auth.UserRepository.UserRepository;
import com.ubplc.ubformsplatform.DTO.Auth.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean register(UserDTO user) {

        if (userRepository.usernameExists(user.getUsername())) {
            return false;
        }

        return userRepository.register(user);
    }

    @Override
    public UserDTO login(String username, String password) {

        UserDTO user = userRepository.findByUsername(username);

        if (user == null) {
            return null;
        }

        if (user.getPassword().equals(password)) {
            return user;
        }

        return null;
    }
}