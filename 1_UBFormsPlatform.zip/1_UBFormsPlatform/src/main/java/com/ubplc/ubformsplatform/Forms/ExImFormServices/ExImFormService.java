package com.ubplc.ubformsplatform.Forms.ExImFormServices;

import java.util.List;

import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormBranch;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormConsolidated;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormMIS;

public interface ExImFormService {
    int save(ExImFormMIS exImFormMIS);
    ExImFormConsolidated update(int formId, ExImFormBranch exImFormBranch);
    List<ExImFormConsolidated> getAllForms();
    ExImFormConsolidated getFormById(int formId);
    String delete(String branchCode);
}
