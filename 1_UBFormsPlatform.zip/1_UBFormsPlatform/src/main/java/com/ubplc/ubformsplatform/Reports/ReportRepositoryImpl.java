package com.ubplc.ubformsplatform.Reports;

import com.ubplc.ubformsplatform.DTO.Branches.BranchDTO;
import com.ubplc.ubformsplatform.DTO.Report.Report;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class ReportRepositoryImpl implements ReportRepository{
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    ReportRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }
    @Override
    public List<Report> showFullReport() {
        List<Report> reports = new ArrayList<>();
        // get the names of branches from the database
        List<BranchDTO> branches = namedParameterJdbcTemplate.query("select branch_code, branch_name from branches", (rs, rowNum) -> {
            BranchDTO branchDTO = new BranchDTO();
            String branchCode = rs.getString("branch_code");
            String branchName = rs.getString("branch_name");
            branchDTO.setBranchCode(branchCode);
            branchDTO.setBranchName(branchName);
            return branchDTO;
        });
        for (BranchDTO branch : branches) {
            reports.add(createReportByBranchCode(branch.getBranchName(), branch.getBranchCode()));
        }
        return reports;
    }
    public Report createReportByBranchCode(String reportName, String branchCode) {
        int thisYear = LocalDateTime.now().getYear();
        int previousYear = thisYear - 1;
        Report report = new Report();
        report.setReportName(reportName);
        report.setBranchCode(branchCode);
        // This year data
        Map<String, Object> previousYearData = getBranchDetailsByBranchCodeAndYear(branchCode, previousYear);
        Map<String, Object> thisYearData = getBranchDetailsByBranchCodeAndYear(branchCode, thisYear);
        report.setPreviousYearImportTargetLCCount((Integer)previousYearData.get("sum_import_lc_target_count"));
        report.setPreviousYearImportActualLCCount((Integer) previousYearData.get("sum_import_lc_actual_count"));
        report.setPreviousYearImportTargetLCAmount((Double) previousYearData.get("sum_import_target_amount"));
        report.setPreviousYearImportActualLCAmount((Double) previousYearData.get("sum_import_lc_actual_amount"));
        report.setPreviousYearExportTargetLCCount((Integer) previousYearData.get("sum_export_lc_target_count"));
        report.setPreviousYearExportActualLCCount((Integer) previousYearData.get("sum_export_lc_actual_count"));
        report.setPreviousYearExportTargetLCAmount((Double) previousYearData.get("sum_export_target_amount"));
        report.setPreviousYearExportActualLCAmount((Double) previousYearData.get("sum_export_lc_actual_amount"));

        report.setThisYearImportTargetLCCount((Integer)thisYearData.get("sum_import_lc_target_count"));
        report.setThisYearImportActualLCCount((Integer) thisYearData.get("sum_import_lc_actual_count"));
        report.setThisYearImportTargetLCAmount((Double) thisYearData.get("sum_import_target_amount"));
        report.setThisYearImportActualLCAmount((Double) thisYearData.get("sum_import_lc_actual_amount"));
        report.setThisYearExportTargetLCCount((Integer) thisYearData.get("sum_export_lc_target_count"));
        report.setThisYearExportActualLCCount((Integer) thisYearData.get("sum_export_lc_actual_count"));
        report.setThisYearExportTargetLCAmount((Double) thisYearData.get("sum_export_target_amount"));
        report.setThisYearExportActualLCAmount((Double) thisYearData.get("sum_export_lc_actual_amount"));
        report.calculateAchievements();
        return report;
    }
    public Map<String, Object> getBranchDetailsByBranchCodeAndYear(String branchCode, int year) {
        Map<String, Object> branchDetails = new HashMap<>();
        String query = """
                select top 1
                	branch_code,
                	year(created_at) as year,
                	sum(import_lc_target_count) as sum_import_lc_target_count,
                	sum(import_lc_actual_count) as sum_import_lc_actual_count,
                	sum(import_target_amount) as sum_import_target_amount,
                	sum(import_lc_actual_amount) as sum_import_lc_actual_amount,
                	sum(export_lc_target_count) as sum_export_lc_target_count,
                	sum(export_lc_actual_count) as sum_export_lc_actual_count,
                	sum(export_target_amount) as sum_export_target_amount,
                	sum(export_lc_actual_amount) as sum_export_lc_actual_amount
                from export_import_target_forms
                group by branch_code, year(created_at)
                having 
                    branch_code = :branchCode and year(created_at) = :year;
                """;
        Map<String, Object> params = Map.of(
                "branchCode", branchCode,
                "year", year
        );
        branchDetails = namedParameterJdbcTemplate.queryForObject(query, params, (rs, rowNum)->{
            Map<String, Object> branchDetailsMap = new HashMap<>();
            branchDetailsMap.put("branch_code", rs.getString("branch_code"));
            branchDetailsMap.put("year", rs.getInt("year"));
            branchDetailsMap.put("sum_import_lc_target_count", rs.getInt("sum_import_lc_target_count"));
            branchDetailsMap.put("sum_import_lc_actual_count", rs.getInt("sum_import_lc_actual_count"));
            branchDetailsMap.put("sum_import_target_amount", rs.getDouble("sum_import_target_amount"));
            branchDetailsMap.put("sum_import_lc_actual_amount", rs.getDouble("sum_import_lc_actual_amount"));
            branchDetailsMap.put("sum_export_lc_target_count", rs.getInt("sum_export_lc_target_count"));
            branchDetailsMap.put("sum_export_lc_actual_count", rs.getInt("sum_export_lc_actual_count"));
            branchDetailsMap.put("sum_export_target_amount", rs.getDouble("sum_export_target_amount"));
            branchDetailsMap.put("sum_export_lc_actual_amount", rs.getDouble("sum_export_lc_actual_amount"));

            return branchDetailsMap;
        });
        return branchDetails;
    }

}
