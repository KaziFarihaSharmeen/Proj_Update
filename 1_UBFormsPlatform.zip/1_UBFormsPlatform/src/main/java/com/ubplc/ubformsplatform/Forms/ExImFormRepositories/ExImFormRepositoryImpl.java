package com.ubplc.ubformsplatform.Forms.ExImFormRepositories;

import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormBranch;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormConsolidated;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormMIS;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class ExImFormRepositoryImpl implements ExImRepository{
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    ExImFormRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }
    @Override
    public int save(ExImFormMIS exImFormMIS) {

        // Create SQL
        String sql = """
                INSERT INTO export_import_target_forms (
                    branch_code,
                    import_lc_target_count,
                    import_target_amount,
                    export_lc_target_count,
                    export_target_amount,
                    deadline_at
                    
                )
                VALUES (:branchCode, :importLCTargetCount, :importLCTargetAmount, :exportLCTargetCount, :exportLCTargetAmount, :deadlineAt);
                """;
        Map<String, Object> params = Map.of(
                "branchCode", exImFormMIS.getBranchCode(),
                "importLCTargetCount", exImFormMIS.getImportLCTargetCount(),
                "importLCTargetAmount", exImFormMIS.getImportLCTargetAmount(),
                "exportLCTargetCount", exImFormMIS.getExportLCTargetCount(),
                "exportLCTargetAmount", exImFormMIS.getExportLCTargetAmount(),
                "deadlineAt", exImFormMIS.getDeadlineAt()
        );
        namedParameterJdbcTemplate.update(sql, params);
        String getIdSql = "SELECT TOP 1 id FROM export_import_target_forms WHERE branch_code = :branchCode AND deadline_at = :deadlineAt ORDER BY created_at DESC;";
        Map<String, Object> getIdParams = Map.of(
                "branchCode", exImFormMIS.getBranchCode(),
                "deadlineAt", exImFormMIS.getDeadlineAt()
        );
        int formId = namedParameterJdbcTemplate.queryForObject(getIdSql, getIdParams, Integer.class);
        return formId;
    }

    @Override
    public List<ExImFormConsolidated> getAllForms() {
        String sql = "SELECT * FROM export_import_target_forms";
        return namedParameterJdbcTemplate.query(sql, (rs, rowNum) -> {
            ExImFormConsolidated exImFormConsolidated = new ExImFormConsolidated();
            exImFormConsolidated.setBranchCode(rs.getString("branch_code"));
            try {
                ExImFormMIS exImFormMIS = new ExImFormMIS(
                        rs.getString("branch_code"),
                        rs.getInt("import_lc_target_count"),
                        rs.getInt("import_target_amount"),
                        rs.getInt("export_lc_target_count"),
                        rs.getInt("export_target_amount"),
                        rs.getDate("deadline_at").toLocalDate()
                );

                exImFormConsolidated.setExImFormMIS(exImFormMIS);
            } catch (RuntimeException e) {
                exImFormConsolidated.setExImFormMIS(null);
            }
            try {
                ExImFormBranch exImFormBranch = new ExImFormBranch(
                        rs.getString("branch_code"),
                        rs.getInt("import_lc_actual_count"),
                        rs.getInt("import_lc_actual_amount"),
                        rs.getInt("export_lc_actual_count"),
                        rs.getInt("export_lc_actual_amount"),
                        rs.getDate("updated_at").toLocalDate()
                );
                exImFormConsolidated.setExImFormBranch(exImFormBranch);
            } catch (RuntimeException e) {
                exImFormConsolidated.setExImFormBranch(null);
            }
            return exImFormConsolidated;
        });
    }
    @Override
    public ExImFormConsolidated getFormById(int formId) {
        String sql = "SELECT TOP 1 * FROM export_import_target_forms WHERE id = :formId;";
        Map<String, Object> params = Map.of("formId", formId);
        return namedParameterJdbcTemplate.queryForObject(sql, params, (rs, rowNum) -> {
            ExImFormConsolidated exImFormConsolidated = new ExImFormConsolidated();
            exImFormConsolidated.setFormId(formId);
            exImFormConsolidated.setBranchCode(rs.getString("branch_code"));
            try{
                ExImFormMIS exImFormMIS = new ExImFormMIS(
                    rs.getString("branch_code"),
                    rs.getInt("import_lc_target_count"),
                    rs.getInt("import_target_amount"),
                    rs.getInt("export_lc_target_count"),
                    rs.getInt("export_target_amount"),
                    rs.getDate("deadline_at").toLocalDate()
            );
            exImFormConsolidated.setExImFormMIS(exImFormMIS);
            } catch (Exception e) {
                // Handle the case where the ExImFormMIS data is not available
                exImFormConsolidated.setExImFormMIS(null);
            }
            try{
                ExImFormBranch exImFormBranch = new ExImFormBranch(
                    rs.getString("branch_code"),
                    rs.getInt("import_lc_actual_count"),
                    rs.getInt("import_lc_actual_amount"),
                    rs.getInt("export_lc_actual_count"),
                    rs.getInt("export_lc_actual_amount"),
                    rs.getDate("updated_at").toLocalDate()
            );
            exImFormConsolidated.setExImFormBranch(exImFormBranch);
            } catch (Exception e) {
                // Handle the case where the ExImFormBranch data is not available
                exImFormConsolidated.setExImFormBranch(null);
            }
            return exImFormConsolidated;
        });
    }
    @Override
    public String delete(String branchCode) {
        String sql = "DELETE FROM export_import_target_forms WHERE branch_code = :branchCode";
        namedParameterJdbcTemplate.update(sql, Map.of("branchCode", branchCode));
        return "Form deleted successfully";
    }
    @Override
    public ExImFormConsolidated update(int formId, ExImFormBranch exImFormBranch) {
        String sql = """
                UPDATE export_import_target_forms
                SET import_lc_actual_count = :importLCActualCount,
                    import_lc_actual_amount = :importLCActualAmount,
                    export_lc_actual_count = :exportLCActualCount,
                    export_lc_actual_amount = :exportLCActualAmount,
                    updated_at = :updatedAt
                WHERE id = :formId
                """;
        Map<String, Object> params = Map.of(
                "formId", formId,
                "importLCActualCount", exImFormBranch.getImportLCActualCount(),
                "importLCActualAmount", exImFormBranch.getImportLCActualAmount(),
                "exportLCActualCount", exImFormBranch.getExportLCActualCount(),
                "exportLCActualAmount", exImFormBranch.getExportLCActualAmount(),
                "updatedAt", exImFormBranch.getUpdateDate()
        );
        namedParameterJdbcTemplate.update(sql, params);
        return getFormById(formId);
    }
}
