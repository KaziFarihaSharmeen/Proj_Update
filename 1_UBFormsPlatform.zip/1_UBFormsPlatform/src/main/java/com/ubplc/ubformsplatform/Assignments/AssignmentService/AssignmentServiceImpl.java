package com.ubplc.ubformsplatform.Assignments.AssignmentService;

import com.ubplc.ubformsplatform.Assignments.FormAssignment;
import com.ubplc.ubformsplatform.Assignments.AssignmentRepository.AssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssignmentServiceImpl implements AssignmentService {


    @Autowired
    private AssignmentRepository repository;


    @Override
    public FormAssignment save(FormAssignment assignment) {
        return repository.save(assignment);
    }


    @Override
    public List<FormAssignment> findAll() {
        return repository.findAll();
    }


    @Override
    public List<FormAssignment> findByBranchCode(String branchCode) {
        return repository.findByBranchCode(branchCode);
    }
}