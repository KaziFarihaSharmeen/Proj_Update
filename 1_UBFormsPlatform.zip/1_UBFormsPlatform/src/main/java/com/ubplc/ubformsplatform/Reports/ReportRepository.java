package com.ubplc.ubformsplatform.Reports;

import com.ubplc.ubformsplatform.DTO.Report.Report;

import java.util.List;
import java.util.Map;

public interface ReportRepository {
    List<Report> showFullReport();
    Report createReportByBranchCode(String reportName, String branchCode);
    Map<String, Object> getBranchDetailsByBranchCodeAndYear(String branchCode, int year);
}
