package com.ubplc.ubformsplatform.Auth.UserRepository;

import com.ubplc.ubformsplatform.DTO.Auth.UserDTO;

public interface UserRepository {

    boolean register(UserDTO user);

    UserDTO findByUsername(String username);

    boolean usernameExists(String username);

}