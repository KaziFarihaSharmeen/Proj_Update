package com.ubplc.ubformsplatform.Auth.UserService;

import com.ubplc.ubformsplatform.DTO.Auth.UserDTO;

public interface UserService {

    boolean register(UserDTO user);

    UserDTO login(String username, String password);

}