package com.ubplc.ubformsplatform.Forms;

import com.ubplc.ubformsplatform.Branches.BranchService.BranchServiceImpl;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormBranch;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormConsolidated;
import com.ubplc.ubformsplatform.DTO.ExImForm.ExImFormMIS;
import com.ubplc.ubformsplatform.Forms.ExImFormServices.ExImFormServiceImpl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ExImFormController {
    private final ExImFormServiceImpl exImFormServiceImpl;
    private final BranchServiceImpl branchService;

    public ExImFormController(
            ExImFormServiceImpl exImFormServiceImpl,
            BranchServiceImpl branchService) {

        this.exImFormServiceImpl = exImFormServiceImpl;
        this.branchService = branchService;
    }
    @GetMapping("")
    public String home(Model model) {
        int formId = 2;
        model.addAttribute("formId", formId);
        return "index";
    }
    @GetMapping("/eximforms")
    public String createExImFormView() {
        return "redirect:/eximforms/mis";
    }

    @GetMapping("/eximforms/mis")
    public String misFormView(Model model) {

        model.addAttribute("exImFormMIS", new ExImFormMIS());
        model.addAttribute("branches", branchService.findAll());
        return "create-exim-form";
    }

    @PostMapping("/eximforms/mis")
    public String createMisForm(@ModelAttribute("exImFormMIS") ExImFormMIS exImFormMIS, Model model) {
        int formId = this.exImFormServiceImpl.save(exImFormMIS);
        ExImFormConsolidated exImFormConsolidated = this.exImFormServiceImpl.getFormById(formId);
        model.addAttribute("exImFormConsolidated", exImFormConsolidated);
        return "exim-form-details";
    }

    @GetMapping("/eximforms/branch/{formId}")
    public String branchFormView(@PathVariable("formId") int formId, Model model) {
        model.addAttribute("exImFormBranch", new ExImFormBranch());
        model.addAttribute("formId", formId);
        return "branch-exim-form";
    }

    @PostMapping("/eximforms/branch/{formId}")
    public String createBranchForm(@ModelAttribute("exImFormBranch") ExImFormBranch exImFormBranch, @PathVariable("formId") int formId, Model model) {
        model.addAttribute("exImFormConsolidated", this.exImFormServiceImpl.update(formId, exImFormBranch));
        return "exim-form-details";
    }

    @GetMapping("/eximforms-list")
    public String getAllExImForms(Model model) {
        List<ExImFormConsolidated> exImForms = this.exImFormServiceImpl.getAllForms();
        model.addAttribute("exImForms", exImForms);
        return "exim-forms-list";
    }
}
