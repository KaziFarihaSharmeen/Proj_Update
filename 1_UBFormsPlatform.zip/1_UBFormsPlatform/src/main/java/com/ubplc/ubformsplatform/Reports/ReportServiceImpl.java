package com.ubplc.ubformsplatform.Reports;


import com.ubplc.ubformsplatform.DTO.Report.Report;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class ReportServiceImpl implements ReportService {
    private final ReportRepository reportRepository;
    ReportServiceImpl(ReportRepository reportRepository) {
        this.reportRepository = reportRepository;
    }
    public Report createReportByBranchCode(String reportName, String branchCode) {
        Report report = this.reportRepository.createReportByBranchCode(reportName, branchCode);
        return report;
    }
    public List<Report> showFullReport() {
        List<Report> reports = this.reportRepository.showFullReport();
        return reports;
    }
}
