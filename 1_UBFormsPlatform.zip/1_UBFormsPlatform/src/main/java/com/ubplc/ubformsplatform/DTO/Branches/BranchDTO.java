package com.ubplc.ubformsplatform.DTO.Branches;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchDTO {

    @NotBlank(message = "Branch Code cannot be blank")
    private String branchCode;

    @NotBlank(message = "Branch Name cannot be blank")
    private String branchName;

    @NotBlank(message = "Branch Address cannot be blank")
    private String branchAddress;

    @NotBlank(message = "Branch Type cannot be blank")
    private String branchType;

    @NotBlank(message = "Branch Zone Cannot Be Blank")
    private String branchZone;
}