package com.ubplc.ubformsplatform.DTO.ExImForm;


import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class ExImFormMIS {
    private String branchCode;
    private int importLCTargetCount;
    private double importLCTargetAmount;
    private int exportLCTargetCount;
    private double exportLCTargetAmount;
    private LocalDate deadlineAt;
}
