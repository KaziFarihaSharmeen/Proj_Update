package com.ubplc.ubformsplatform.Assignments.AssignmentRepository;

import com.ubplc.ubformsplatform.Assignments.FormAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AssignmentRepository extends JpaRepository<FormAssignment, Long> {

    List<FormAssignment> findByBranchCode(String branchCode);

}