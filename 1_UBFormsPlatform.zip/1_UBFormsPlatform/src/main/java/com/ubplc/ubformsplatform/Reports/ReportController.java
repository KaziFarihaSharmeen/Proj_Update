package com.ubplc.ubformsplatform.Reports;

import com.ubplc.ubformsplatform.DTO.Report.Report;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reports")
public class ReportController {
    private final ReportService reportService;
    ReportController(ReportService reportService) {
        this.reportService = reportService;
    }
    @GetMapping("/create")
    String createAndShowReport(@PathVariable String reportName,@PathVariable String branchCode, Model model) {
        Report report = this.reportService.createReportByBranchCode(reportName, branchCode);
        model.addAttribute("report", report);
        return "show-report";
    }
    @GetMapping("/show-full-report")
    String createAndShowFullReport(Model model) {
        List<Report> reports = this.reportService.showFullReport();
        model.addAttribute("reports", reports);
        return "show-full-report";
    }
}
