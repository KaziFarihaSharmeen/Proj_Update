package com.ubplc.ubformsplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UbFormsPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(UbFormsPlatformApplication.class, args);
    }

}
