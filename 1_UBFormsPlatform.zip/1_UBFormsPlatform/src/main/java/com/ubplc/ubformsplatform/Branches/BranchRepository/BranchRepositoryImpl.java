package com.ubplc.ubformsplatform.Branches.BranchRepository;

import com.ubplc.ubformsplatform.DTO.Branches.BranchDTO;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class BranchRepositoryImpl implements BranchRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public BranchRepositoryImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public BranchDTO save(BranchDTO branchRequest) {

        String sql = """
                INSERT INTO dbo.branches
                (
                    branch_code,
                    branch_name,
                    branch_address,
                    branch_zone,
                    branch_type
                )
                VALUES
                (
                    :branchCode,
                    :branchName,
                    :branchAddress,
                    :branchZone,
                    :branchType
                )
                """;

        Map<String, Object> params = Map.of(
                "branchCode", branchRequest.getBranchCode(),
                "branchName", branchRequest.getBranchName(),
                "branchAddress", branchRequest.getBranchAddress(),
                "branchZone", branchRequest.getBranchZone(),
                "branchType", branchRequest.getBranchType()
        );

        jdbcTemplate.update(sql, params);

        return findByBranchCode(branchRequest.getBranchCode());
    }

    @Override
    public BranchDTO findByBranchCode(String branchCode) {

        String sql = """
                SELECT
                    branch_code,
                    branch_name,
                    branch_address,
                    branch_zone,
                    branch_type
                FROM dbo.branches
                WHERE branch_code = :branchCode
                """;

        return jdbcTemplate.queryForObject(
                sql,
                Map.of("branchCode", branchCode),
                (rs, rowNum) -> BranchDTO.builder()
                        .branchCode(rs.getString("branch_code"))
                        .branchName(rs.getString("branch_name"))
                        .branchAddress(rs.getString("branch_address"))
                        .branchZone(rs.getString("branch_zone"))
                        .branchType(rs.getString("branch_type"))
                        .build()
        );
    }

    @Override
    public List<BranchDTO> findAll() {

        String sql = """
                SELECT
                    branch_code,
                    branch_name,
                    branch_address,
                    branch_zone,
                    branch_type
                FROM dbo.branches
                ORDER BY branch_code
                """;

        return jdbcTemplate.query(
                sql,
                (rs, rowNum) -> BranchDTO.builder()
                        .branchCode(rs.getString("branch_code"))
                        .branchName(rs.getString("branch_name"))
                        .branchAddress(rs.getString("branch_address"))
                        .branchZone(rs.getString("branch_zone"))
                        .branchType(rs.getString("branch_type"))
                        .build()
        );
    }

    @Override
    public BranchDTO update(BranchDTO branchRequest) {

        String sql = """
                UPDATE dbo.branches
                SET
                    branch_name = :branchName,
                    branch_address = :branchAddress,
                    branch_zone = :branchZone,
                    branch_type = :branchType
                WHERE branch_code = :branchCode
                """;

        Map<String, Object> params = Map.of(
                "branchCode", branchRequest.getBranchCode(),
                "branchName", branchRequest.getBranchName(),
                "branchAddress", branchRequest.getBranchAddress(),
                "branchZone", branchRequest.getBranchZone(),
                "branchType", branchRequest.getBranchType()
        );

        jdbcTemplate.update(sql, params);

        return findByBranchCode(branchRequest.getBranchCode());
    }

    @Override
    public void delete(String branchCode) {

        String sql = """
                DELETE FROM dbo.branches
                WHERE branch_code = :branchCode
                """;

        jdbcTemplate.update(sql, Map.of("branchCode", branchCode));
    }

    @Override
    public BranchDTO search(String branchCode) {

        String sql = """
                SELECT
                    branch_code,
                    branch_name,
                    branch_address,
                    branch_zone,
                    branch_type
                FROM dbo.branches
                WHERE branch_code = :branchCode
                """;

        return jdbcTemplate.queryForObject(
                sql,
                Map.of("branchCode", branchCode),
                (rs, rowNum) -> BranchDTO.builder()
                        .branchCode(rs.getString("branch_code"))
                        .branchName(rs.getString("branch_name"))
                        .branchAddress(rs.getString("branch_address"))
                        .branchZone(rs.getString("branch_zone"))
                        .branchType(rs.getString("branch_type"))
                        .build()
        );
    }
}