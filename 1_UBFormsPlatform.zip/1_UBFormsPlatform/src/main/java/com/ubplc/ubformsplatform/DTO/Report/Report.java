package com.ubplc.ubformsplatform.DTO.Report;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Report {
    private String branchCode;
    private String reportName; // the title of the table
    private int previousYearImportTargetLCCount;
    private int previousYearImportActualLCCount;
    private double previousYearImportTargetLCAmount;
    private double previousYearImportActualLCAmount;
    private int previousYearExportTargetLCCount;
    private int previousYearExportActualLCCount;
    private double previousYearExportTargetLCAmount;
    private double previousYearExportActualLCAmount;
    private int thisYearImportTargetLCCount;
    private int thisYearImportActualLCCount;
    private double thisYearImportTargetLCAmount;
    private double thisYearImportActualLCAmount;
    private int thisYearExportTargetLCCount;
    private int thisYearExportActualLCCount;
    private double thisYearExportTargetLCAmount;
    private double thisYearExportActualLCAmount;

    // calculated fields
    private float previousYearImportAchievementCount;
    private double previousYearImportAchievementAmount;
    private float previousYearExportAchievementCount;
    private double previousYearExportAchievementAmount;
    private float thisYearImportAchievementCount;
    private double thisYearImportAchievementAmount;
    private float thisYearExportAchievementCount;
    private double thisYearExportAchievementAmount;

    public void calculateAchievements() {
        // calculate in percentage
        this.previousYearImportAchievementCount = (previousYearImportActualLCCount / previousYearImportTargetLCCount) * 100;
        this.previousYearImportAchievementAmount = (previousYearImportActualLCAmount / previousYearImportTargetLCAmount) * 100;
        this.previousYearExportAchievementCount = (previousYearExportActualLCCount / previousYearExportTargetLCCount) * 100;
        this.previousYearExportAchievementAmount = (previousYearExportActualLCAmount / previousYearExportTargetLCAmount) * 100;
        this.thisYearImportAchievementCount = (thisYearImportActualLCCount / thisYearImportTargetLCCount) * 100;
        this.thisYearImportAchievementAmount = (thisYearImportActualLCAmount / thisYearImportTargetLCAmount) * 100;
        this.thisYearExportAchievementCount = (thisYearExportActualLCCount / thisYearExportTargetLCCount) * 100;
        this.thisYearExportAchievementAmount = (thisYearExportActualLCAmount / thisYearExportTargetLCAmount) * 100;
    }
}
