package com.ubplc.ubformsplatform.Auth.UserRepository;

import com.ubplc.ubformsplatform.Config.JDBCConfig;
import com.ubplc.ubformsplatform.DTO.Auth.UserDTO;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@Repository
public class UserRepositoryImpl implements UserRepository {

    @Override
    public boolean register(UserDTO user) {

        String sql = "INSERT INTO users(username,password,role) VALUES(?,?,?)";

        try (
                Connection con = JDBCConfig.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getRole());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public UserDTO findByUsername(String username) {

        String sql = "SELECT * FROM users WHERE username=?";

        try (
                Connection con = JDBCConfig.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                UserDTO user = new UserDTO();

                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));

                return user;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean usernameExists(String username) {

        String sql = "SELECT COUNT(*) FROM users WHERE username=?";

        try (
                Connection con = JDBCConfig.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}