CREATE TABLE branches (
	branch_code varchar(100) primary key,
	branch_name varchar(256) not null,
	branch_address varchar(256) not null,
	branch_type varchar(50) null
);