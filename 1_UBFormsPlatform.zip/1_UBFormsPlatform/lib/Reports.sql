CREATE TABLE reports (
    id BIGINT IDENTITY(1,1) PRIMARY KEY,

    report_name VARCHAR(255) NOT NULL,
    branch_code VARCHAR(50) NOT NULL,

    previous_year_import_target_lc_count INT DEFAULT 0,
    previous_year_import_target_lc_amount DECIMAL(18,2) DEFAULT 0,

    previous_year_export_target_lc_count INT DEFAULT 0,
    previous_year_export_target_lc_amount DECIMAL(18,2) DEFAULT 0,

    this_year_import_target_lc_count INT DEFAULT 0,
    this_year_import_target_lc_amount DECIMAL(18,2) DEFAULT 0,

    this_year_export_target_lc_count INT DEFAULT 0,
    this_year_export_target_lc_amount DECIMAL(18,2) DEFAULT 0,

    CONSTRAINT FK_reports_branch
        FOREIGN KEY (branch_code)
        REFERENCES branch(branch_code)
);