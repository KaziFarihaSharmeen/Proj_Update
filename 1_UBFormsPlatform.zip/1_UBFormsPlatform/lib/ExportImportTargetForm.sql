use mis_project;
CREATE TABLE export_import_target_form (
    id INT IDENTITY(1,1) PRIMARY KEY,

    branch_code varchar(100) NOT NULL,

    -- Import
    import_lc_target_count INT NULL,
    import_lc_actual_count INT NULL,
    import_target_amount DECIMAL(13,2) NULL,
    import_lc_actual_amount DECIMAL(13,2) NULL,

    -- Export
    export_lc_target_count INT NULL,
    export_lc_actual_count INT NULL,
    export_target_amount DECIMAL(13,2) NULL,
    export_lc_actual_amount DECIMAL(13,2) NULL,

    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NULL,
    deadline_at DATETIME2 NULL,
    submitted_at DATETIME2 NULL,

    CONSTRAINT fk_export_import_target_form_branch
        FOREIGN KEY (branch_code)
        REFERENCES branches(branch_code)
);
GO